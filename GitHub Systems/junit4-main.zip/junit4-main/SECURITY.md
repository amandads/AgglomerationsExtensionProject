# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 4.13.x  | :white_check_mark: |
| < 4.13  | :x:                |

## Reporting a Vulnerability

To report a security vulnerability, please send an email to security@junit.org.
