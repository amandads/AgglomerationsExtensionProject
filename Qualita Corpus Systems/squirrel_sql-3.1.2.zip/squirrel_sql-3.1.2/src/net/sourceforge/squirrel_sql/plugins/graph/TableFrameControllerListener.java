package net.sourceforge.squirrel_sql.plugins.graph;


public interface TableFrameControllerListener
{
   void closed(TableFrameController tfc);
}
