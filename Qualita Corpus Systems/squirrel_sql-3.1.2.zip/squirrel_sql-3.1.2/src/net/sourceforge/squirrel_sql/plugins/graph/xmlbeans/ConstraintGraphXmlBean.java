package net.sourceforge.squirrel_sql.plugins.graph.xmlbeans;


public class ConstraintGraphXmlBean
{
   private FoldingPointXmlBean[] foldingPointXmlBeans;

   public FoldingPointXmlBean[] getFoldingPointXmlBeans()
   {
      return foldingPointXmlBeans;
   }

   public void setFoldingPointXmlBeans(FoldingPointXmlBean[] foldingPointXmlBeans)
   {
      this.foldingPointXmlBeans = foldingPointXmlBeans;
   }
}
