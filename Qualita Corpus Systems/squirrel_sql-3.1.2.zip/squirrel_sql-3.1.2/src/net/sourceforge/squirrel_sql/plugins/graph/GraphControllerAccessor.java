package net.sourceforge.squirrel_sql.plugins.graph;

import java.util.Vector;

public interface GraphControllerAccessor
{
   Vector<TableFrameController> getOpenTableFrameControllers();
}
