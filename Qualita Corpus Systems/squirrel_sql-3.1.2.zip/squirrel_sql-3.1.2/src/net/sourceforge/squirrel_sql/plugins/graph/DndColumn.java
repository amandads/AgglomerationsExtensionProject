package net.sourceforge.squirrel_sql.plugins.graph;

public interface DndColumn
{
   DndEvent getDndEvent();
   void setDndEvent(DndEvent dndEvent);
}
