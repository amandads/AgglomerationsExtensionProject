package net.sourceforge.squirrel_sql.plugins.graph;

public interface ColumnSortListener
{
   void columnOrderChanged();
}
