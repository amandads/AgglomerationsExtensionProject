package net.sourceforge.squirrel_sql.plugins.graph;

import java.awt.*;

public class ConnectionPoints
{
   Point[] points;
   boolean pointsAreLeftOfWindow;

}
