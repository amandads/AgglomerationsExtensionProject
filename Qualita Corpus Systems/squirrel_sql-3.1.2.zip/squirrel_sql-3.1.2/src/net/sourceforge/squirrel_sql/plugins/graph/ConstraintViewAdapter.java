package net.sourceforge.squirrel_sql.plugins.graph;

public class ConstraintViewAdapter implements ConstraintViewListener
{
   @Override
   public void foldingPointMoved(ConstraintView source)
   {
   }

   @Override
   public void removeNonDbConstraint(ConstraintView constraintView)
   {
   }
}
