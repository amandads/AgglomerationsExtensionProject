package net.sourceforge.squirrel_sql.plugins.graph.xmlbeans;


public class PrintXmlBean
{
   private int edgesScale;
   private boolean showEdges;

   public int getEdgesScale()
   {
      return edgesScale;
   }

   public void setEdgesScale(int edgesScale)
   {
      this.edgesScale = edgesScale;
   }

   public boolean isShowEdges()
   {
      return showEdges;
   }

   public void setShowEdges(boolean showEdges)
   {
      this.showEdges = showEdges;
   }
}
