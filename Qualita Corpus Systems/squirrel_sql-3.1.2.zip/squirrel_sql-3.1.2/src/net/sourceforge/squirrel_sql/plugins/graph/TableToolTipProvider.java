package net.sourceforge.squirrel_sql.plugins.graph;

import java.awt.event.MouseEvent;

public interface TableToolTipProvider
{
   String getToolTipText(MouseEvent event);
}
