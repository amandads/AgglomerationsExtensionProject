package net.sourceforge.squirrel_sql.plugins.graph;

public interface EdgesListener
{
   public void edgesGraphComponentChanged(EdgesGraphComponent edgesGraphComponent, boolean put);
}
